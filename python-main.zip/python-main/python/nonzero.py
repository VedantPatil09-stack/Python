n = float(input("Enter a number: "))
if n == 0:
    print("The number is ZERO.")
else:
    print("The number is NON-ZERO.")
